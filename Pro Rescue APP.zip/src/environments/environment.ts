
export const environment = {
    production: false,
    token: 'd8ea7bcbfd9a4621bb67efc75b658fad'
  };
  