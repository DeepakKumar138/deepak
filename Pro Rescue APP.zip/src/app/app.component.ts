import { OverviewPage } from './../pages/overview/overview';
import { ChatbotPage } from './../pages/chatbot/chatbot';
import { Component, ViewChild } from '@angular/core';
import { Nav, Platform } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { HomePage } from '../pages/home/home';
import { ListPage } from '../pages/list/list';
import { RescueMePage } from '../pages/rescue-me/rescue-me';
import { NeedHelpListPage } from '../pages/need-help-list/need-help-list';
import { ProvideHelpPage } from '../pages/provide-help/provide-help';
import { UserHandlerProvider } from '../providers/user-handler/user-handler';


@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  rootPage: any = HomePage;

  pages: Array<{title: string, component: any}>;

  constructor(public platform: Platform, public statusBar: StatusBar,
               public splashScreen: SplashScreen,
               private uh: UserHandlerProvider) {
    this.initializeApp();

    // used for an example of ngFor and navigation
    this.pages = [
      { title: 'Overview', component: OverviewPage },
      { title: 'Rescue Me', component: RescueMePage },
      { title: 'Chat Support', component: ChatbotPage }

      
    ];

  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }


  logout(){
    this.uh.Logout();
    this.uh.checkAuth();
  }
  openPage(page) {
    this.nav.setRoot(page.component);
  }
}
