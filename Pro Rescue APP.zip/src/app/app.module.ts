import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule, NavController } from 'ionic-angular';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { ListPage } from '../pages/list/list';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { LoginComponent } from '../components/login/login';
import { SignupComponent } from '../components/signup/signup';
import { HttpClientModule } from '@angular/common/http';
import { OverviewPage } from '../pages/overview/overview';
import { AgmCoreModule } from '@agm/core';
import { RescueMePage } from '../pages/rescue-me/rescue-me';
import { Geolocation } from '@ionic-native/geolocation';
import { RescueMonitorPage } from '../pages/rescue-monitor/rescue-monitor';
import { AgmJsMarkerClustererModule } from '@agm/js-marker-clusterer';
import { AgmDirectionModule } from 'agm-direction';
import { UserHandlerProvider } from '../providers/user-handler/user-handler';
import { NeedHelpListPage } from '../pages/need-help-list/need-help-list';
import { NeedHelpDetailsPage } from '../pages/need-help-details/need-help-details';
import { ProvideHelpPage } from '../pages/provide-help/provide-help';
import { MockDisasterPage } from '../pages/mock-disaster/mock-disaster';
import { DialogflowService } from '../services/dialogflow.service';
import { MessageListComponent } from '../components/message-list/message-list.component';
import {  MessageFormComponent } from '../components/message-form/message-form.component';
import {  MessageItemComponent } from '../components/message-item/message-item.component';
import { ChatbotPage } from '../pages/chatbot/chatbot';

import {HttpModule} from '@angular/http';
import { FabchatbotComponent } from '../components/fabchatbot/fabchatbot';


@NgModule({
  declarations: [
    MyApp,
    HomePage,
    ListPage,
    LoginComponent,
    SignupComponent,
    OverviewPage,
    RescueMePage,
    RescueMonitorPage,
    NeedHelpListPage,
    NeedHelpDetailsPage,
    ProvideHelpPage,
    MockDisasterPage,
    MessageListComponent,
    MessageFormComponent,
    MessageItemComponent,
    ChatbotPage,
    FabchatbotComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    IonicModule.forRoot(MyApp),
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyDCOMOdHB6zWgJPk4Zf3HJnEyXp2q40R_k'
    }),
    AgmJsMarkerClustererModule,
    AgmDirectionModule 
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    ListPage,
    OverviewPage,
    RescueMePage,
    RescueMonitorPage,
    NeedHelpListPage,
    NeedHelpDetailsPage,
    ProvideHelpPage,
    MockDisasterPage,
    ChatbotPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    Geolocation,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    UserHandlerProvider,
    DialogflowService,
    HttpModule
  ]
})
export class AppModule {}
