import { HomePage } from './../../pages/home/home';
import { HttpClient } from '@angular/common/http';
import { Injectable, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';

@Injectable()
export class UserHandlerProvider {

  //stores current location
  currentLat: number;
  currentLng: number;

  //stores userdata
  userData: any;

  //stores nearest rescue team and returns
  nearestRescueTeam: any;

  token: string = '';
  @ViewChild('nav') nav: NavController;


  constructor(public http: HttpClient
  ) {

  }
  //sets location
  setLocation(lat, lng) {
    this.currentLat = lat;
    this.currentLng = lng;
  }

  //gets location


  getLocation() {

    return {
      lat: this.currentLat,
      lng: this.currentLng
    }

  }
  //set user data
  setUserData(data) {
    this.userData = data;
  }
  //gets user data
  getUserData() {
    return this.userData;
  }

  setData(obj) {
    this.userData = obj;
  }

  getData() {
    return this.userData;
  }

  //sets jwt token
  setToken(token) {
    this.token = token;
  }
//gets jwt token
  getToken() {
    return this.token;
  }


  //check auth
  checkAuth() {
    if (this.token == '') {
      return false;
    }
    else {
      return true;
    }
  }

  //logs out user

  Logout() {
    this.token = '';
    this.userData={};
  }



  rad(x) {
    return x * Math.PI / 180;
  }

  //calulates closest marker based on markers array list and current location
  find_closest_marker(loading, currentLocation, markers) {
    var lat = currentLocation.lat;
    var lng = currentLocation.lng;
    var R = 6371; // radius of earth in km
    var distances = [];
    var closest = -1;
    for (let i = 0; i < markers.length; i++) {
      var mlat = markers[i].lat;
      var mlng = markers[i].lng;
      var dLat = this.rad(mlat - lat);
      var dLong = this.rad(mlng - lng);
      var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(this.rad(lat)) * Math.cos(this.rad(lat)) * Math.sin(dLong / 2) * Math.sin(dLong / 2);
      var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      var d = R * c;
      distances[i] = d;
      if (closest == -1 || d < distances[closest]) {
        closest = i;
      }
    }
    console.log("########nearest marker");
    this.nearestRescueTeam = markers[closest];
    console.log(markers[closest].lat);
    loading.dismiss();
    return this.nearestRescueTeam;
  }


}
