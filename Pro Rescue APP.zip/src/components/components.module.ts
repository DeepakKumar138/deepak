import { NgModule } from '@angular/core';
import { LoginComponent } from './login/login';
import { SignupComponent } from './signup/signup';
import { FabchatbotComponent } from './fabchatbot/fabchatbot';
@NgModule({
	declarations: [LoginComponent,
    SignupComponent,
    FabchatbotComponent],
	imports: [],
	exports: [LoginComponent,
    SignupComponent,
    FabchatbotComponent]
})
export class ComponentsModule {}
