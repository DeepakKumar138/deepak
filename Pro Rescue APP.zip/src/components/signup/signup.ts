import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NavController, ToastController } from 'ionic-angular';

@Component({
  selector: 'signup',
  templateUrl: 'signup.html'
})
export class SignupComponent {

  email: string='';
  password:string='';
  confirmPassword:string='';
  phoneNumber: string='';
  gender:any='';
  address:any='';

  constructor(public navCtrl: NavController,
              public httpClient: HttpClient,
              private toastCtrl: ToastController) {


  }
//tost function to show signup status
  presentToast(str) {
    let toast = this.toastCtrl.create({
      message:  str,
      duration: 3000,
      position: 'bottom'
    });
  
    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });
  
    toast.present();
  }

  //signup function to save new user data

  save(form:any,valid:any){
    // console.log(this.password);
    // console.log(form);
    // console.log(valid);


    var user = {
      email: form.email,
      password: form.password,
      phoneNumber: form.phoneNumber,
      address: form.address,
      gender: form.gender
    };

    // console.log(user);

// signup api
    this.httpClient.post('https://disastermgm.eu-gb.mybluemix.net/signup',user)
    .subscribe((data:any)=>{
      console.log(data);

      // success case
      if(data.success==true){
        this.email='';
        this.password='';
        this.confirmPassword='';
        this.phoneNumber='';
        this.gender='';
        this.address='';
        this.presentToast('Thanks for signingUp. Please continue to login');
      
      }
      else{
        // unsuccessful case
        this.email='';
        this.presentToast('Account already exists!');
      }
      
    },
  (err)=>{
    //error case
    this.presentToast('Error!');
  })
  }
}
