import { Component } from '@angular/core';


@Component({
  selector: 'fabchatbot',
  templateUrl: 'fabchatbot.html'
})
export class FabchatbotComponent {

  text: string;

  constructor() {
    console.log('Hello FabchatbotComponent Component');
    this.text = 'Hello World';
  }

}
