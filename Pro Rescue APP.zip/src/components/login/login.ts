import { Component } from '@angular/core';
import { NavController, ToastController } from 'ionic-angular';
import { HttpClient } from '@angular/common/http';
import { OverviewPage } from '../../pages/overview/overview';
import { UserHandlerProvider } from '../../providers/user-handler/user-handler';


@Component({
  selector: 'login',
  templateUrl: 'login.html'
})
export class LoginComponent {


  email: string = '';
  password: string = '';

  constructor(public navCtrl: NavController,
    public httpClient: HttpClient,
    private uh: UserHandlerProvider,
    private toastCtrl: ToastController) {

  }

  //toast fntion to show  status of login to user
  presentToast(str) {

    let toast = this.toastCtrl.create({
      message: str,
      duration: 2000,
      position: 'bottom'
    });

    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });

    toast.present();
  }

  //login form function
  login(form: any, valid: any) {

    var user = {
      email: form.email,
      password: form.password
    };

    // login api
    this.httpClient.post('http://disastermgm.eu-gb.mybluemix.net/api/authenticate', user)
      .subscribe((data: any) => {
        console.log(data);

        if (data.success == true) {
          //sets the jwt token recieved in userhandler service
          this.uh.setToken(data.token);
          //fetches the token from service for data retrieval
          var obj = { email: user.email, token: this.uh.getToken() };
          console.log(obj);
          this.presentToast('Fetching Details!');

          //fetch user data api
          this.httpClient.post('https://disastermgm.eu-gb.mybluemix.net/api/userData', obj)
            .subscribe((data) => {
              // console.log(data);
              //set data in service
              this.uh.setUserData(data);
              //navigate to Overview page on successful login
              this.navCtrl.setRoot(OverviewPage);
            })


        } else {
          //unsuccessful login
          this.presentToast('Wrong credentials!');
        }

      })


  }

}
