import { Component, OnInit, Input } from '@angular/core';
import { Message } from '../../models/message';
import { DialogflowService } from '../../services/dialogflow.service';

@Component({
  selector: 'message-form',
  templateUrl: './message-form.component.html'
  // styleUrls: ['./message-form.component.scss']
})
export class MessageFormComponent implements OnInit {

  @Input('message')
  private message : Message;

  @Input('messages')
  private messages : Message[];

  constructor(private dialogFlowService: DialogflowService) { }

  ngOnInit() {
  }

  //sends message to server via service
  public sendMessage(): void {
    this.message.timestamp = new Date();
    this.messages.push(this.message);
    
    this.dialogFlowService.getResponse(this.message.content).subscribe((res:any) => {
      console.log(res.result.fulfillment.speech);
      this.messages.push(
        new Message(res.result.fulfillment.speech, '../../assets/imgs/bot.png', res.timestamp)
      );
    });

    this.message = new Message('', '../../assets/imgs/user.png');
  }

}
