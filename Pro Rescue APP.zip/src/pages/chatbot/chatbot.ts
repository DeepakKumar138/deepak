import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Message } from '../../models';
import { OverviewPage } from '../overview/overview';


@IonicPage()
@Component({
  selector: 'page-chatbot',
  templateUrl: 'chatbot.html',
})
export class ChatbotPage {
  //meassage object
  public message: Message;
  //list of all messages of chat
  public messages: Message[];

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    //configuration
    this.message = new Message('', '../../assets/imgs/user.png');
    //initial message
    this.messages = [
      new Message('Welcome to Pro Rescue Chat Support', '../../assets/imgs/bot.png', new Date())
    ];
  }

  //navigates back to overview page
  navigateTorescue() {
    this.navCtrl.setRoot(OverviewPage);
  }

}
