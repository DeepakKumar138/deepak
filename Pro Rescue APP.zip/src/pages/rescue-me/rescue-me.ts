import { Component, OnDestroy } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { ViewChild } from '@angular/core';
import { Slides } from 'ionic-angular';
import { RescueMonitorPage } from '../rescue-monitor/rescue-monitor';
import { UserHandlerProvider } from '../../providers/user-handler/user-handler';


@IonicPage()
@Component({
  selector: 'page-rescue-me',
  templateUrl: 'rescue-me.html',
})
export class RescueMePage implements OnDestroy {

  //slides reference
  @ViewChild(Slides) slides: Slides;
  //current location of user
  currentlat: number;
  currentlng: number;

  //user alone status
  alone: boolean = true;
  //stores if any old/child/or disabled is with user
  childrenDisabledOrOld: boolean = false;
  //stores injury status
  injured: boolean = false;
  //current slide
  currenslide: number = 0;
  //location subscription
  subscription:any;


  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    private geolocation: Geolocation,
    private uh: UserHandlerProvider,
    public loadingCtrl: LoadingController) {
//gets location if locatioi is not there
      if(this.uh.getLocation()==undefined){
        let loading = this.loadingCtrl.create({
          content: 'Detecting Location...'
        });
      
        loading.present();
  
       this.subscription = this.geolocation.watchPosition()
        .filter((p) => p.coords !== undefined) //Filter Out Errors
        .subscribe(position => {
          loading.dismiss();
          console.log(position.coords.longitude + ' ' + position.coords.latitude);
          this.currentlat = position.coords.latitude;
          this.currentlng = position.coords.longitude;
          this.uh.setLocation(this.currentlat, this.currentlng);
          console.log(this.uh.getLocation());
        });
      }else{
        //gets location
        this.currentlat= this.uh.getLocation().lat;
        this.currentlng= this.uh.getLocation().lng;
        console.log(this.currentlat);
        console.log(this.currentlng);
      }
  

  }


//controls slide for questions/rescue info
  goToSlide(i, val) {
    if (this.currenslide == 0) {
      this.alone = val;
    }
    if (this.currenslide == 1) {
      this.childrenDisabledOrOld = val;
    }

    if (this.currenslide == 2) {
      this.injured = val;
      this.navigaretoRescueMonitor();
    }
    if (this.currenslide != 2) {
      this.slides.slideTo(i, 500);
      this.currenslide = i;
    }


  }

  //sets user data and goes to rescue monitir page
  navigaretoRescueMonitor() {
    this.uh.setData({
      'name':'Test Name',
      ...this.uh.getUserData(),
      'gender':'Male',
       'alone':this.alone,
       'old/children/disabled':this.childrenDisabledOrOld,
       'injured':this.injured
    })
    this.navCtrl.push(RescueMonitorPage);
  }
//destroys subscription
  ngOnDestroy(){
    if(this.subscription!=undefined){
      this.subscription.unsubscribe();
    }
    
  }

}
