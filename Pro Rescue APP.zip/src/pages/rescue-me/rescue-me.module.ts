import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RescueMePage } from './rescue-me';

@NgModule({
  declarations: [
    RescueMePage,
  ],
  imports: [
    IonicPageModule.forChild(RescueMePage),
  ],
})
export class RescueMePageModule {}
