import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NeedHelpDetailsPage } from './need-help-details';

@NgModule({
  declarations: [
    NeedHelpDetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(NeedHelpDetailsPage),
  ],
})
export class NeedHelpDetailsPageModule {}
