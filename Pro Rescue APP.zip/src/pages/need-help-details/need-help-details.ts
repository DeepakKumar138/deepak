import { Component, OnDestroy } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import { UserHandlerProvider } from '../../providers/user-handler/user-handler';
import { Geolocation } from '@ionic-native/geolocation';

@IonicPage()
@Component({
  selector: 'page-need-help-details',
  templateUrl: 'need-help-details.html',
})
export class NeedHelpDetailsPage implements OnDestroy {

  helpCategory:any;
  lat: number = 51.673858;
  lng: number = 7.815982;
  currentLocation:any;
  iconurl = "../../assets/imgs/rescue_map_icon3.png";
  zoom=12;
  subscription:any;

  markers: marker[] = [
    {
      lat: 12.839024,
      lng: 77.656472,
    },
    {
      lat: 12.841320,
      lng: 77.649813
    },
    {
      lat: 12.828097,
      lng: 77.649469
    },
    {
      lat: 12.831109,
      lng: 77.678052
    },
    {
      lat: 12.832609,
      lng: 77.672926
    },

    {
      lat: 12.875288,
      lng: 77.672790
    },
    {
      lat: 12.876589,
      lng: 77.685415
    },
    {
      lat: 12.869134,
      lng: 77.680680
    },
    {
      lat: 12.880022,
      lng: 77.684201
    },
    {
      lat: 12.878071,
      lng: 77.695048
    },
    {
      lat: 12.810367,
      lng: 77.679782
    },
    {
      lat: 12.811313,
      lng: 77.689492
    },
    {
      lat: 12.801348,
      lng: 77.690002
    },
    {
      lat: 12.806095,
      lng: 77.678740
    },
    {
      lat: 12.816472,
      lng: 77.693505
    }
  ];

  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private uh: UserHandlerProvider  ,
              private geolocation: Geolocation,
              public loadingCtrl: LoadingController) {

    this.helpCategory =  this.navParams.get('helpCategory');
    this.iconurl= "../../assets/imgs/"+this.helpCategory+"map.png";

 if(this.uh.getLocation()!=undefined){
  this.currentLocation = this.uh.getLocation();
 }else{
  let loading = this.loadingCtrl.create({
    content: 'Detecting Location...'
  });

  loading.present();

this.subscription = this.geolocation.watchPosition()
  .filter((p) => p.coords !== undefined) //Filter Out Errors
  .subscribe(position => {
    loading.dismiss();
    console.log(position.coords.longitude + ' ' + position.coords.latitude);
    
    this.uh.setLocation(position.coords.latitude,position.coords.longitude);
    console.log(this.uh.getLocation());
    this.currentLocation = this.uh.getLocation();
  });
 }

    console.log(this.helpCategory);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NeedHelpDetailsPage');
  }

  ngOnDestroy(){
    if(this.subscription!=undefined){
      this.subscription.unsubscribe();
    }
    
  }

}

interface marker {
  lat: number;
  lng: number;
}

