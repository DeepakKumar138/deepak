import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import { RescueMePage } from '../rescue-me/rescue-me';
import { google } from '@agm/core/services/google-maps-types';
import { HttpClient } from '@angular/common/http';
import { UserHandlerProvider } from '../../providers/user-handler/user-handler';


@IonicPage()
@Component({
  selector: 'page-rescue-monitor',
  templateUrl: 'rescue-monitor.html',
})
export class RescueMonitorPage {

//direction to show nearest rescue team
  dir = undefined;
  //user data
  userData: any;
  //ico for rescue team
  iconurl = "../../assets/imgs/rescue_map_icon3.png";


  zoom: number = 16;

  // initial center position for the map
  lat: number = 51.673858;
  lng: number = 7.815982;
  //current location of user
  currentLocation: any;
  //nearest rescue team marker
  nearestRescueTeam: any;

  public markerOptions: any;

  public renderOptions = {
    suppressMarkers: true,
  }


  userdataAloneicon = "../../assets/imgs/uncheck.png";
  userdataDisabledicon = "../../assets/imgs/uncheck.png";
  userdataInjuredicon = "../../assets/imgs/uncheck.png";

 
//mock rescue team markers
  markers: marker[] = [
    {
      lat: 12.839024,
      lng: 77.656472,
    },
    {
      lat: 12.841320,
      lng: 77.649813
    },
    {
      lat: 12.828097,
      lng: 77.649469
    },
    {
      lat: 12.831109,
      lng: 77.678052
    },
    {
      lat: 12.832609,
      lng: 77.672926
    },

    {
      lat: 12.875288,
      lng: 77.672790
    },
    {
      lat: 12.876589,
      lng: 77.685415
    },
    {
      lat: 12.869134,
      lng: 77.680680
    },
    {
      lat: 12.880022,
      lng: 77.684201
    },
    {
      lat: 12.878071,
      lng: 77.695048
    },
    {
      lat: 12.810367,
      lng: 77.679782
    },
    {
      lat: 12.811313,
      lng: 77.689492
    },
    {
      lat: 12.801348,
      lng: 77.690002
    },
    {
      lat: 12.806095,
      lng: 77.678740
    },
    {
      lat: 12.816472,
      lng: 77.693505
    }
  ];

  constructor(public loadingCtrl: LoadingController,
    public navCtrl: NavController,
    public navParams: NavParams,
    public httpClient: HttpClient,
    private uh: UserHandlerProvider) {


    let loading = this.loadingCtrl.create({
      content: 'Detecting Location...'
    });

    loading.present();


    this.currentLocation = this.uh.getLocation();

    this.userData = this.uh.getData();
    console.log(this.userData);
    //controls user infowindow
    if (this.userData.alone) {
      this.userdataAloneicon = "../../assets/imgs/check.png";
    }

    if (this.userData.injured == true) {
      this.userdataInjuredicon = "../../assets/imgs/check.png";
    }

    if (this.userData['old/children/disabled']) {
      this.userdataDisabledicon = "../../assets/imgs/check.png";
    }
//custom markers
    this.markerOptions = {
      origin: {
        icon: '../../assets/imgs/person.png',
        infoWindow: "<h3>" + this.userData[0].mobileNumber + "</h3>  <br><div style='display:flex;justify-content:center;align-items:center'><div><b>Gender -</b></div> <div>" + this.userData.gender + "</div></div>   <br><div style='display:flex;justify-content:center;align-items:center'><div><b>Email -</b></div> <div>" + this.userData[0].email + "</div></div>    <br> <div style='display:flex;justify-content:center;align-items:center'><div><b>Alone -</b></div> <div><img src='" + this.userdataAloneicon + "' height='22' width='22'></div></div>           <br><div style='display:flex;justify-content:center;align-items:center'><div><b>Injured -</b></div> <div><img src='" + this.userdataInjuredicon + "'  height='22' width='22'></div></div><br><div style='display:flex;justify-content:center;align-items:center'><div><b>Children/old/disabled -</b></div> <div><img src='" + this.userdataDisabledicon + "'  height='22' width='22'></div></div>"
      }
    };
//finds closest rescue team
    this.find_closest_marker(loading);
    // this.getRescueTeamLiveLocations();
  }
//finds closest rescue team
  find_closest_marker(loading) {
    this.nearestRescueTeam = this.uh.find_closest_marker(loading, this.currentLocation, this.markers);
  }



//fetches all location of rescue tema
  getRescueTeamLiveLocations() {
    this.httpClient.get('../../assets/data/rescueTeam.json')
      .subscribe(data => {
        console.log(data);
        // this.markers=data;
      })
  }

}

interface marker {
  lat: number;
  lng: number;
}

