import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RescueMonitorPage } from './rescue-monitor';

@NgModule({
  declarations: [
    RescueMonitorPage,
  ],
  imports: [
    IonicPageModule.forChild(RescueMonitorPage),
  ],
})
export class RescueMonitorPageModule {}
