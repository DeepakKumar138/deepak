import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import { UserHandlerProvider } from '../../providers/user-handler/user-handler';
import { HomePage } from '../home/home';
import { HttpClient } from '@angular/common/http';
import { RescueMePage } from '../rescue-me/rescue-me';
import { ProvideHelpPage } from '../provide-help/provide-help';
import { NeedHelpListPage } from '../need-help-list/need-help-list';


@IonicPage()
@Component({
  selector: 'page-mock-disaster',
  templateUrl: 'mock-disaster.html',
})
export class MockDisasterPage implements OnInit {


  //marker array for mock disater location
  markers: marker[] = new Array();
  //zoom of map default
  zoom: number = 11;
  //mock disaster logo
  iconurl = "../../assets/imgs/gas.png";
  //lat-ln initial
  lat: number = 0;
  lng: number = 0;
  //initial radius of fire
  radius = 1000;

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public httpClient: HttpClient,
    private uh: UserHandlerProvider,
    public loadingCtrl: LoadingController) {

    if (!this.uh.checkAuth()) {
      this.navCtrl.setRoot(HomePage);
    }


  }

  ngOnInit() {

    //reads current location of user for mock disaster
    this.lat = this.uh.getLocation().lat;
    this.lng = this.uh.getLocation().lng;

    let loading = this.loadingCtrl.create({
      content: 'Creating Mock Fire Disaster...'
    });

    //loading begins
    loading.present();

    //gets all gas sensor location
    this.httpClient.post("https://disastermgm.eu-gb.mybluemix.net/getSensor", { "type": "gas" })
      .subscribe((data: any) => {
        console.log(data);
        //shows current active gas sensors where sisater has occured
        for (let i = 0; i < data.length; i++) {
          if (data[i].value > 950) {
            this.markers.push({ lat: data[i].lat, lng: data[i].lng });
          }

        }
        //loading stops
        loading.dismiss();
      })
    //increases radius of fire//mock
    setInterval(() => {
      this.radius += 100;
    }, 1000);
  }


  //navigates to Rescume
  navigateToRescue() {
    this.navCtrl.push(RescueMePage);
  }
  //navigate to providehelp
  navigateToProvideHelp() {
    this.navCtrl.push(ProvideHelpPage);
  }

  //navigate to Help list
  navigateToHelpList() {
    this.navCtrl.push(NeedHelpListPage);
  }






}

// just an interface for type safety.
interface marker {
  lat: number;
  lng: number;
}
