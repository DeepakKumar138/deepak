import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MockDisasterPage } from './mock-disaster';

@NgModule({
  declarations: [
    MockDisasterPage,
  ],
  imports: [
    IonicPageModule.forChild(MockDisasterPage),
  ],
})
export class MockDisasterPageModule {}
