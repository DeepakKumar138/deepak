import { ChatbotPage } from './../chatbot/chatbot';
import { MockDisasterPage } from './../mock-disaster/mock-disaster';
import { HomePage } from './../home/home';
import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController } from 'ionic-angular';
import { RescueMePage } from '../rescue-me/rescue-me';
import { HttpClient } from '@angular/common/http';
import { UserHandlerProvider } from '../../providers/user-handler/user-handler';
import { Geolocation } from '@ionic-native/geolocation';
import { NeedHelpListPage } from '../need-help-list/need-help-list';
import { ProvideHelpPage } from '../provide-help/provide-help';

@Component({
  selector: 'page-overview',
  templateUrl: 'overview.html',
})
export class OverviewPage {

  //location subscription
  subscription: any;
  //direction object
  dir = undefined;
  //user data variable
  userData: any;
  //icon for safehouse
  iconurl = "../../assets/imgs/safeHouse.png";
  //zoom level of map
  zoom: number = 8;
  // initial center position for the map equals to my current location
  lat: number = 51.673858;
  lng: number = 7.815982;
  //current location of user
  currentLocation: any = {};
  //nearest rescue team marker object
  nearestRescueTeam: any;


  //marker variables
  public markerOptions: any;

  public renderOptions = {
    suppressMarkers: true,
  }

  //safe houses mock locations
  markers: marker[] = [
    {
      lat: 12.839024,
      lng: 77.656472,
    },
    {
      lat: 12.841320,
      lng: 77.649813
    },
    {
      lat: 12.828097,
      lng: 77.649469
    },
    {
      lat: 12.831109,
      lng: 77.678052
    },
    {
      lat: 12.832609,
      lng: 77.672926
    },

    {
      lat: 12.875288,
      lng: 77.672790
    },
    {
      lat: 12.876589,
      lng: 77.685415
    },
    {
      lat: 12.869134,
      lng: 77.680680
    },
    {
      lat: 12.880022,
      lng: 77.684201
    },
    {
      lat: 12.878071,
      lng: 77.695048
    },
    {
      lat: 12.810367,
      lng: 77.679782
    },
    {
      lat: 12.811313,
      lng: 77.689492
    },
    {
      lat: 12.801348,
      lng: 77.690002
    },
    {
      lat: 12.806095,
      lng: 77.678740
    },
    {
      lat: 12.816472,
      lng: 77.693505
    }
  ];

  constructor(public loadingCtrl: LoadingController,
    public navCtrl: NavController,
    public navParams: NavParams,
    public httpClient: HttpClient,
    private geolocation: Geolocation,
    private uh: UserHandlerProvider) {

    //auth guard function check
    if (!this.uh.checkAuth()) {
      this.navCtrl.setRoot(HomePage);
    }

    console.log(this.uh.getUserData());

    //starts detecting location
    let loading = this.loadingCtrl.create({
      content: 'Detecting Location...'
    });

    //waiting starts
    loading.present();

    this.subscription = this.geolocation.watchPosition()
      .filter((p) => p.coords !== undefined) //Filter Out Errors
      .subscribe(position => {
        console.log(position.coords.longitude + ' ' + position.coords.latitude);
        //location fetched
        //setting location
        this.currentLocation.lat = position.coords.latitude;
        this.currentLocation.lng = position.coords.longitude;
        console.log(this.currentLocation);
        //setting location service for faster retrieval
        this.uh.setLocation(this.currentLocation.lat, this.currentLocation.lng);
        // console.log(this.uh.getLocation());
        //setting custom marker options
        this.markerOptions = {
          origin: {
            icon: '../../assets/imgs/person.png',
            infoWindow: '<h1>hii</h1>'
          }
        };

        //calling closest marker algo
        this.find_closest_marker(loading);


      });







  }

  //returns closest marker to user location and controls loading 
  find_closest_marker(loading) {
    console.log(this.currentLocation);
    this.nearestRescueTeam = this.uh.find_closest_marker(loading, this.currentLocation, this.markers);
  }

  //generates mock disatser and alert user on map for it
  navigateToMockDiaster() {
    this.navCtrl.push(MockDisasterPage);
  }



  //fetches all location of rescue tems
  getRescueTeamLiveLocations() {
    this.httpClient.get('../../assets/data/rescueTeam.json')
      .subscribe(data => {
        console.log(data);
        // this.markers=data;
      })
  }

  //navigate to rescue page
  navigateToRescue() {
    this.navCtrl.push(RescueMePage);
  }

  //navigate to provide help page
  navigateToProvideHelp() {
    this.navCtrl.push(ProvideHelpPage);
  }

  //navigate to help list page
  navigateToHelpList() {
    this.navCtrl.push(NeedHelpListPage);
  }

  //cancels location subscription
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}

//marker interface
interface marker {
  lat: number;
  lng: number;
}

