import { NeedHelpDetailsPage } from './../need-help-details/need-help-details';
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';


@IonicPage()
@Component({
  selector: 'page-need-help-list',
  templateUrl: 'need-help-list.html',
})
export class NeedHelpListPage {

  helpCategories = new Array();
  constructor(public navCtrl: NavController,
    public navParams: NavParams) {

    //VARIOUS CATEGORIES FOR HELP DURING DISASTER
    this.helpCategories = ['Food', 'Accomodation', 'Doctor_Nurse', 'Electrician', 'Police', 'FireFighter', 'Relief Camp', 'Relief Materials'];

 

  }

  //navigate to selected category and disaply help partners
  //captures real and mock partners both
  navigateTohelp(data) {
    console.log(data);
    let paramObj = { helpCategory: data };
    this.navCtrl.push(NeedHelpDetailsPage, paramObj);
  }

}
