import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NeedHelpListPage } from './need-help-list';

@NgModule({
  declarations: [
    NeedHelpListPage,
  ],
  imports: [
    IonicPageModule.forChild(NeedHelpListPage),
  ],
})
export class NeedHelpListPageModule {}
