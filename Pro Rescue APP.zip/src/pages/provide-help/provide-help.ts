import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { OverviewPage } from '../overview/overview';
import { HttpClient } from '@angular/common/http';


@IonicPage()
@Component({
  selector: 'page-provide-help',
  templateUrl: 'provide-help.html',
})
export class ProvideHelpPage {

//category of help
  category: any = '';

  //user schema for help
  user: any = {
    food: {
      count: 0
    },
    stay: {
      male: 0,
      female: 0
    },
    job: {
      type: ''
    },
    relief: {
      available: false
    }
  }

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public httpClient: HttpClient,
    private toastCtrl: ToastController) {
  }

//presents toats
  presentToast(str) {
    let toast = this.toastCtrl.create({
      message: str,
      duration: 2000,
      position: 'bottom'
    });

    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });

    toast.present();
  }


//display selected category in console
  editCategory() {
    console.log(this.category);
  }

//saves the helping partner data and presents toast
  continue() {
    console.log(this.user);

    var partner = {
      foodcount: this.user.food.count,
      maleStay: this.user.stay.male,
      femaleStay: this.user.stay.female,
      job: this.user.job.type,
      relief: this.user.relief.available
    };

    console.log(partner);

    this.httpClient.post('http://disastermgm.eu-gb.mybluemix.net/userHelp', {}).
      subscribe((data) => {
        this.presentToast('Thanks for becoming our partner');
        this.navCtrl.setRoot(OverviewPage);

      },
        (err) => {
          this.presentToast('Error!');
        })


  }
}
