import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ProvideHelpPage } from './provide-help';

@NgModule({
  declarations: [
    ProvideHelpPage,
  ],
  imports: [
    IonicPageModule.forChild(ProvideHelpPage),
  ],
})
export class ProvideHelpPageModule {}
