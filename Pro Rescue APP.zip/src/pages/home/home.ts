import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import {Validators, FormBuilder, FormGroup } from '@angular/forms';
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
//responsible for toggling of login and signup form
  showLogin:boolean = true;
  showsignup:boolean = false;
  constructor(public navCtrl: NavController) {

  }

}
