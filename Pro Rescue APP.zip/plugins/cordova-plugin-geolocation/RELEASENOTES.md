### 4.0.1 (Dec 27, 2017)
* [CB-13705](https://issues.apache.org/jira/browse/CB-13705) Fix to allow 4.0.0 version install

